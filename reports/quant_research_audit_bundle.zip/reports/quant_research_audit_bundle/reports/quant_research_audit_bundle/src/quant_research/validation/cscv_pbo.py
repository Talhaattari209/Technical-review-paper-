import itertools
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional


class CSCVPBOCalculator:
    """Combinatorially Symmetric Cross-Validation (CSCV) and Probability of Backtest Overfitting (PBO).

    Implements Bailey, Borwein, Lopez de Prado, and Zhu (2016).
    Partition matrix into M even blocks (M must be even, e.g. M=16).
    Evaluates N strategy trial return vectors across C(M, M/2) combinations.
    """

    def __init__(self, m_blocks: int = 16, max_combinations: Optional[int] = None, random_state: int = 42):
        if m_blocks % 2 != 0:
            raise ValueError(f"m_blocks must be an even integer, got {m_blocks}")
        self.m_blocks = m_blocks
        self.max_combinations = max_combinations
        self.random_state = random_state

    def compute_pbo(
        self,
        trial_returns: pd.DataFrame,
        output_audit_csv: Optional[str] = None,
    ) -> Dict[str, float]:
        """Calculates PBO and produces a partition-by-partition audit table.

        Args:
            trial_returns: DataFrame where each column is the return series of a tested strategy trial.
            output_audit_csv: Optional path to persist the full partition evaluation audit table.
        """
        T, N = trial_returns.shape
        if N < 2:
            raise ValueError("CSCV PBO requires at least 2 strategy trials to rank.")

        block_size = T // self.m_blocks
        if block_size < 2:
            raise ValueError(f"Time series length {T} too short for {self.m_blocks} blocks.")

        # Aggregate Sharpe ratio per block for each strategy
        block_sharpes = np.zeros((self.m_blocks, N))
        for b in range(self.m_blocks):
            sub_chunk = trial_returns.iloc[b * block_size : (b + 1) * block_size].values
            means = np.mean(sub_chunk, axis=0)
            stds = np.std(sub_chunk, axis=0) + 1e-8
            block_sharpes[b, :] = (means / stds) * np.sqrt(252)

        half_m = self.m_blocks // 2
        combinations = list(itertools.combinations(range(self.m_blocks), half_m))
        total_theoretical_combs = len(combinations)

        # Sample combinations if configured to keep runtime bounded
        is_subsampled = False
        if self.max_combinations is not None and len(combinations) > self.max_combinations:
            rng = np.random.default_rng(self.random_state)
            comb_indices = rng.choice(len(combinations), size=self.max_combinations, replace=False)
            combinations = [combinations[i] for i in comb_indices]
            is_subsampled = True

        audit_records = []
        logits = []
        is_suboptimal_count = 0

        for part_id, train_blocks in enumerate(combinations):
            test_blocks = [b for b in range(self.m_blocks) if b not in train_blocks]

            is_sharpe = np.mean(block_sharpes[list(train_blocks), :], axis=0)
            oos_sharpe = np.mean(block_sharpes[test_blocks, :], axis=0)

            best_is_idx = int(np.argmax(is_sharpe))

            # Rank of best IS strategy in OOS
            oos_ranks = np.argsort(np.argsort(oos_sharpe))  # 0 to N-1
            best_is_oos_rank = int(oos_ranks[best_is_idx])

            # omega_s: relative rank in [0, 1]
            omega_s = (best_is_oos_rank + 1.0) / (N + 1.0)

            # Logit transformation lambda_s
            omega_clipped = float(np.clip(omega_s, 1e-4, 1.0 - 1e-4))
            lambda_s = float(np.log(omega_clipped / (1.0 - omega_clipped)))
            logits.append(lambda_s)

            # Suboptimal if OOS rank is in the lower 50% (lambda_s < 0)
            is_suboptimal = bool(lambda_s < 0.0)
            if is_suboptimal:
                is_suboptimal_count += 1

            audit_records.append(
                {
                    "partition_id": part_id,
                    "train_blocks": str(list(train_blocks)),
                    "test_blocks": str(test_blocks),
                    "best_is_trial_idx": best_is_idx,
                    "best_is_sharpe": float(is_sharpe[best_is_idx]),
                    "oos_sharpe": float(oos_sharpe[best_is_idx]),
                    "oos_rank": best_is_oos_rank,
                    "omega_s": float(omega_s),
                    "lambda_s": lambda_s,
                    "is_suboptimal": is_suboptimal,
                }
            )

        pbo = is_suboptimal_count / len(combinations)

        if output_audit_csv is not None:
            audit_df = pd.DataFrame(audit_records)
            audit_df.to_csv(output_audit_csv, index=False)

        return {
            "pbo": float(pbo),
            "n_combinations_evaluated": len(combinations),
            "total_theoretical_combinations": total_theoretical_combs,
            "is_subsampled": is_subsampled,
            "mean_logit": float(np.mean(logits)),
            "m_blocks": self.m_blocks,
            "n_trials": N,
        }
