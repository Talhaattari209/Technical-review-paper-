import numpy as np
import pandas as pd
from typing import List, Dict, Tuple
from quant_research.discovery.grammar import ExpressionNode
from quant_research.discovery.novelty import AlphaNoveltyArchive
from quant_research.execution.accounting import FrictionAccountingEngine


class GeneticAlphaExplorer:
    """Explores alpha space using genetic expression search with multi-objective Pareto optimization."""

    def __init__(
        self,
        features_df: pd.DataFrame,
        asset_returns: pd.Series,
        volumes: pd.Series,
        feature_names: List[str],
        population_size: int = 20,
        n_generations: int = 5,
        friction_engine: FrictionAccountingEngine = None,
        random_seed: int = 42,
    ):
        self.features_df = features_df
        self.asset_returns = asset_returns
        self.volumes = volumes
        self.feature_names = feature_names
        self.population_size = population_size
        self.n_generations = n_generations
        self.friction_engine = friction_engine or FrictionAccountingEngine()
        self.rng = np.random.default_rng(random_seed)
        self.archive = AlphaNoveltyArchive(novelty_threshold=0.15)
        self.trial_records: List[Dict] = []

    def _random_tree(self, depth: int = 2) -> ExpressionNode:
        if depth == 0 or self.rng.random() < 0.4:
            feat = self.rng.choice(self.feature_names)
            return ExpressionNode(op="FEATURE", value=feat)
        op = self.rng.choice(["ADD", "SUB", "MUL", "DIV"])
        left = self._random_tree(depth - 1)
        right = self._random_tree(depth - 1)
        return ExpressionNode(op=op, children=[left, right])

    def evaluate_node(self, node: ExpressionNode) -> Dict[str, float]:
        raw_signal = node.evaluate(self.features_df)
        # Position mapping: normalize signal to [-1, 1]
        std = raw_signal.std()
        if std < 1e-8 or np.isnan(std):
            return {"sharpe": -999.0, "ic": 0.0, "turnover": 0.0}

        norm_signal = (raw_signal - raw_signal.mean()) / std
        target_positions = norm_signal.clip(-1.0, 1.0)

        # Performance under friction
        perf = self.friction_engine.compute_net_returns(self.asset_returns, target_positions, self.volumes)
        net_ret = perf["net_return"].dropna()

        if len(net_ret) < 20 or net_ret.std() < 1e-8:
            return {"sharpe": -999.0, "ic": 0.0, "turnover": 0.0}

        sharpe = (net_ret.mean() / net_ret.std()) * np.sqrt(252)

        # 1-day forward IC
        forward_ret = self.asset_returns.shift(-1)
        valid = ~(norm_signal.isna() | forward_ret.isna())
        ic = np.corrcoef(norm_signal[valid], forward_ret[valid])[0, 1] if np.sum(valid) > 20 else 0.0
        if np.isnan(ic):
            ic = 0.0

        return {
            "sharpe": float(sharpe),
            "ic": float(ic),
            "turnover": float(target_positions.diff().abs().mean()),
        }

    def run_search(self) -> List[Dict]:
        population = [self._random_tree(depth=2) for _ in range(self.population_size)]

        for gen in range(self.n_generations):
            evaluated_pop = []
            for node in population:
                metrics = self.evaluate_node(node)
                raw_sig = node.evaluate(self.features_df)
                is_novel, novelty_dist = self.archive.check_and_add(node, raw_sig, metrics)
                record = {
                    "generation": gen,
                    "metrics": metrics,
                    "novelty_dist": novelty_dist,
                    "node": node,
                }
                self.trial_records.append(record)
                evaluated_pop.append(record)

            # Keep top candidates based on combination of Sharpe and Novelty
            evaluated_pop.sort(key=lambda x: (x["metrics"]["sharpe"] + 0.5 * x["novelty_dist"]), reverse=True)
            survivors = [item["node"] for item in evaluated_pop[: self.population_size // 2]]

            # Mutate and cross-over to reform population
            new_pop = list(survivors)
            while len(new_pop) < self.population_size:
                parent = self.rng.choice(survivors)
                # Mutation: replace a branch with a random sub-tree
                mutated = ExpressionNode(
                    op=self.rng.choice(["ADD", "SUB", "MUL"]),
                    children=[parent, self._random_tree(depth=1)],
                )
                new_pop.append(mutated)
            population = new_pop

        return self.archive.archive_records
